clc
clear all
close all
I1 = imread('1.jpg');
I2 = imread('5.jpg');
score = inputimage(I1,I2);
%feature = trainfeatures(I1);
